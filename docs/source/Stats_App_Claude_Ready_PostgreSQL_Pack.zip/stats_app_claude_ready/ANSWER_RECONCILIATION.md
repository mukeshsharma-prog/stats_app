# Stats App — Answer Reconciliation

**Source:** `Stats_App_Answers_v1_0.docx` and the supplied `netstats.json`.  
**Status:** Incorporated into the v1.2 implementation update.

## Decisions now closed

| Reference | Answer received | Implementation consequence |
|---|---|---|
| Q1 | Java 21; Spring Boot greater than 3.5.x | Use Java 21. The exact Spring Boot patch/minor version and internal reference project still need to be fixed in the build version catalog. |
| Q2 | One Docker image for each module | Build three deployable images: Input, Writer, and API. |
| C1 | One queue per stat type | Use per-type queues; the singular `app_statsstore` is a naming prefix only. |
| Q4 | `netstats.json` supplied | `netstats` can enter the implementation scope, but the supplied file is a sample, not a complete formal schema. Nested optionality and constraints require confirmation or documented implementation defaults. |
| Q5 | Every record has a tenant | Require `tenant`; derive API tenant from the validated token. |
| Q6 | `uid` unique; Heimdal does not deliver duplicates | Keep a PostgreSQL unique constraint on `uid` as defense against broker redelivery and race conditions. |
| Q7 | Heimdal already sends the correct OMS timestamp | Remove Stats App timestamp normalization. Canonical input is already `ts.processor`. |
| Q9 | Heimdal handles dead-lettering when it receives non-2xx | Input returns non-2xx on broker failure; no local Input buffer. |
| Q12 | ZC owns Heimdal Core | Use ZC as the upstream contract owner/contact. |
| Q14 | Dominant query pattern: tenant, gateway, `ts.device` | PostgreSQL indexes and API query design must prioritize `(tenant, gateway, ts.device)`. |
| Q15 | PostgreSQL only; phased delivery is allowed for each stat type | Remove MongoDB from the implementation path and documentation. |
| D1 | Java logger to Docker logs; format is up to engineering | Use structured JSON where practical, but Docker stdout/stderr is the V1 sink. |
| D2 | Payload may be logged | This is accepted for V1 but requires a security warning, configurable logging, and redaction of tokens/secrets. Payloads may contain identifiers such as IMSI. |
| D4 | HTTP success after broker confirmation | Implement publisher confirms before 2xx. |
| D5 | RabbitMQ unavailable => non-2xx | Use 503 for transient broker unavailability unless platform convention requires another non-2xx status. |
| D9 | Retention uses `ts.device` | PostgreSQL retention must be based on device timestamp. Late-arriving records may be near expiry on arrival; this is an accepted business rule that must be documented/tested. |
| D3 | RFC 9457 response shape confirmed | Use the approved Problem Details shape. |
| D6 | Published message is identical to received | No OMS or other transformation in Input; validate and publish the received canonical message. |
| D8 | `uid` is its own PostgreSQL column | Do not use a Mongo `_id`; use a PostgreSQL `uid` column with a unique constraint/index. |
| D10 | `omsstats` is in scope | Include it in every type list. |

## Answers that remain ambiguous or need an implementation choice

| Reference | Remaining point | Required next action |
|---|---|---|
| Q1 | “Spring Boot > 3.5.x” is not a reproducible version. | Select an exact supported Spring Boot version, Gradle version catalog, and internal reference service. |
| Q3 | “Every module declares exchanges, queues and bindings” conflicts with service boundaries if it literally includes the API. | Interpret as every broker-connected deployable; confirm whether `stats-api` should have RabbitMQ dependencies. Use shared topology constants and an identical-declaration integration test. |
| Q4 | `netstats.json` shows one sample but does not state whether `eth0`, `wwan`, their nested fields, and `dns` are mandatory or extensible. | Confirm formal schema or record the v1 implementation policy before strict validation. |
| Q8 | A dummy `readOnly` role is permitted, but realm, client, issuer, audience, and tenant claim remain to be configured. | Use local dummy values only in development; keep all values in properties/environment and create a security ADR for deployment. |
| Q11 | “See file in mail” does not provide a complete edge-case sample set in this workspace. | Obtain representative optional/malformed/late/replay samples from ZC/Heimdal. |
| D7 | ACK timing is left to engineering. | Choose ACK after successful PostgreSQL transaction/duplicate-safe result; this is safest for STA-25. |
| D11 | Batch versus individual writes is left to engineering. | Start with individual writes for correctness; benchmark PostgreSQL at the clarified peak and introduce safe batching only with per-record failure handling. |
| D12 | Invalid-filter behavior is left to engineering. | Reject inverted ranges with 400; document retention limits and query timestamp as `ts.device`. |
| D13 | Health checks are left to engineering. | Use separate liveness/readiness; readiness checks PostgreSQL and RabbitMQ as appropriate for each module. |

## Volume correction

The answer text writes `160k*10*6*24*numberOfStat`, but “every 10 minutes” means **six reporting intervals per hour**, not ten. The corrected calculation is:

```text
records per type per day = 160,000 gateways × 6 × 24
                         = 23,040,000 records/type/day

4 types = 92,160,000 records/day
5 types = 115,200,000 records/day

steady records/second/type = 160,000 / 600 = 266.67
steady records/second for 4 types = 1,066.67
steady records/second for 5 types = 1,333.33
```

These are average rates. If gateways report on synchronized ten-minute boundaries, the burst rate is materially higher and must be load-tested. PostgreSQL partitioning, retention, index size, connection pools, batching, and queue capacity must be sized against the burst envelope, not only the average.

## `netstats` sample interpretation

The supplied record contains the common envelope and this payload shape:

```text
data.eth0.apipa : string IP address
data.eth0.gw    : string IP address
data.eth0.tx    : string counter
data.eth0.rx    : string counter
data.eth0.ip    : string IP address
data.eth0.dns   : array of string IP addresses
data.eth0.mask  : string IP address/mask

data.wwan.gw    : string IP address
data.wwan.tx    : string counter
data.wwan.rx    : string counter
data.wwan.ip    : string IP address
data.wwan.dns   : array of string IP addresses
data.wwan.mask  : string IP address/mask

data.timespan  : integer seconds
```

The sample does not establish whether `eth0` and `wwan` are always present, whether additional interfaces are allowed, whether `apipa` is optional, or whether counters must remain strings. A schema catalogue entry is therefore created as a **draft** and must be confirmed before strict rejection rules are finalized.
