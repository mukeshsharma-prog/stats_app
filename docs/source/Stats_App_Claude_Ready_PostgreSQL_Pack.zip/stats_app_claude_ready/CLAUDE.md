# CLAUDE.md — Stats App Implementation Rules

## 1. Mission

Build the **Stats App** as a Datahub Core add-on that accepts statistics records from Heimdal Core, validates and buffers them through RabbitMQ, persists them per stat type in **PostgreSQL**, and exposes them through a tenant-scoped, read-only REST API.

The intended build is a multi-module Gradle project with three independently deployable application services:

```text
stats-common   shared envelope, DTOs, schema registry interfaces, shared errors
stats-input    HTTP POST -> authenticate -> validate -> AMQP publish
stats-writer   AMQP consume -> persist -> retention/indexes -> metrics
stats-api      GET-only API -> Keycloak authentication -> tenant-scoped reads
```

RabbitMQ and MongoDB are **infrastructure dependencies**, not Stats App deployables. Never describe them as application modules.

## 2. Required reading order

Before planning or editing code, read in this order:

1. This file.
2. `CODE_START_CHECKLIST.md`.
3. The original source requirement and the matching SRS v1.1 amendment.
4. The relevant ADR and contract under `docs/architecture/adr/` and `docs/contracts/`.
5. The relevant schema under `docs/schemas/`.
6. The relevant test criteria in the implementation request.

If two documents disagree, **do not pick an answer**. Quote the conflict, name the affected requirements, and request an ADR or approved amendment.

## 3. Non-negotiable invariants

These rules derive from the SRS and cannot be relaxed by a coding shortcut.

| Rule | Implementation consequence |
|---|---|
| The Stats API is read-only. | Module 3 exposes GET endpoints only. POST, PUT, PATCH, and DELETE return 405 and no API code path writes data. |
| The Stats Writer is the only database writer. | `stats-input` and `stats-api` must never hold a write-capable database dependency or call a writer service directly. PostgreSQL is the only V1 database; do not add MongoDB code or dependencies. |
| Tenant isolation is server-side. | Derive the effective tenant solely from the validated access token; add it to every repository query; never trust a request tenant parameter, header, or body. |
| Per-type isolation is required. | Every stat type has its own routing key, queue, consumer, collection, indexes, retention configuration, metrics labels, and endpoint operation. |
| New types are additive. | Adding a type must not modify code handling existing types. Extend through a registry/plugin-style adapter and add a new isolated artifact/configuration. |
| Invalid ingress is visible. | Return 400 for validation failure, log safe metadata, publish nothing, and expose an error response that does not contain device-identifying values. |
| Write failure is visible. | Apply the approved retry policy and send permanently failed records to a DLQ; never swallow exceptions or drop a message. |
| Queues are durable and messages persistent. | The broker must survive routine restart without losing accepted messages. |
| A success response means broker acceptance. | Do not respond with success until the approved publisher-confirm condition completes. |
| Timestamps are Unix seconds. | Convert seconds correctly; never interpret payload timestamps as milliseconds. |

## 4. Data rules

All record types use the common envelope:

```json
{
  "uid": "<unique record id>",
  "tenant": "<assigned tenant>",
  "maintenant": "<managing tenant>",
  "gateway": "<12-character hexadecimal gateway MAC>",
  "type": "<stat type>",
  "ts": { "processor": 0, "device": 0 },
  "data": {}
}
```

Treat `tenant` and `maintenant` as different business fields. The approved query/isolation field is `tenant`; every test suite must contain fixtures where they differ. Do not add `netstats` validation or storage until a versioned schema has been approved. The OMS legacy `ts.converter` handling remains blocked until ADR-004 is approved.

## 5. Decisions that code must not invent

The following must have an approved ADR or requirement amendment before the affected code is written:

| Decision | Blocked implementation |
|---|---|
| Language, JDK, Spring Boot version, and platform reference repository | Build files and dependency configuration. |
| Inbound Heimdal authentication and identity | Input endpoint security. |
| `netstats` schema and V1 scope | All `netstats` work. |
| Tenant claim mapping and tenantless-record policy | API authorization and persistence validation. |
| Queue naming, exchange type, retry strategy, DLQ/redrive policy, and topology owner | RabbitMQ configuration. |
| `uid` uniqueness and duplicate semantics | Idempotency and message acknowledgement behavior. |
| Exact retention timestamp and MongoDB retention mechanism | TTL index/deletion configuration. |
| Approved OpenAPI | Public endpoint paths, filters, response models, pagination, and errors. |
| Capacity/SLO and deployment model | Production concurrency, replica count, queue limits, timeouts, and index assumptions. |

Use `PENDING APPROVAL` clearly in documentation. Never silently convert a recommendation into a production behavior.

## 6. PostgreSQL implementation rules

PostgreSQL is the only V1 persistence technology. Use PostgreSQL-compatible Spring Data/JDBC/JPA conventions only after the approved table/partition/index design exists. Use versioned migrations for every schema change. Test persistence against a real PostgreSQL Testcontainer. Do not introduce MongoDB drivers, `MongoRepository`, TTL-index code, Mongo Compose services, `_id` semantics, or Mongo-specific documentation.

The dominant query pattern is `(tenant, gateway, ts.device)`. PostgreSQL indexes, partitions, and API queries must support that pattern without JSON path scans. Retention is based on `ts.device`; the retention strategy must be explicitly selected for PostgreSQL because the previous MongoDB TTL approach is no longer applicable.

## 7. Code structure rules

1. Use constructor injection. Do not use field injection.
2. Keep controllers thin: parse/authenticate/validate/delegate/map response only.
3. Keep application behavior behind interfaces where an implementation changes by stat type or storage strategy.
4. Each module may depend on `stats-common`; no application module may depend directly on another application module.
5. Read configuration from `application.properties` through typed configuration properties. Do not hard-code operational values or secrets.
6. Treat config as immutable per process unless an approved live-reconfiguration design exists.
7. Use UTC internally and serialize API timestamps only as defined in the approved OpenAPI.
8. Make all pagination deterministic with an indexed sort and a unique tie-breaker.
9. Use RFC 9457 Problem Details unless the approved Datahub platform error convention differs.
10. Do not add a dependency without explaining why Spring Boot or the approved platform libraries cannot already provide the capability.

## 8. Logging, security, and data handling

V1 permits payload logging to the Java logger/Docker logs. Keep payload logging configurable and document its production level, retention, access, and data-classification impact. Never log access tokens, passwords, private keys, or secrets; redact them if they appear in a payload. Always include `uid`, stat type, tenant, gateway, module, event, and error code for correlation. Do not echo full payloads in HTTP error responses.

The required correlation ID is `uid`, unless an approved replacement is introduced. Log events must permit traceability across `input`, `writer`, and `api` modules. Payload logging is an accepted V1 decision, but Docker log retention/access must be explicitly configured because records can contain IMSI and device identifiers.

## 9. Required development workflow for Claude

For every task, follow this sequence.

1. **Inspect.** Read the required source documents and relevant existing code/tests.
2. **Plan.** State requirements, assumptions, files to change, tests, failure behavior, and decisions that block work.
3. **Wait.** Do not edit until the user approves the plan, unless the request explicitly asks for a small, reversible documentation-only edit.
4. **Implement minimally.** Make the narrowest change that meets the named requirements.
5. **Test.** Run focused unit tests, then relevant integration/contract tests. Do not claim a test passed without running it.
6. **Review.** Explain the requirement mapping, tests run and results, unresolved risks, and documentation updates.

## 10. Mandatory tests

| Change type | Mandatory tests |
|---|---|
| New payload/schema | Valid sample, every missing mandatory field, wrong type, unknown stat type, time values in seconds, safe error response. |
| Messaging/persistence | Correct routing key and queue, durable declaration, publisher-confirm behavior, retry limit, DLQ, duplicate/redelivery behavior, and collection selection. |
| API/query/security | 401, 403, GET success, every non-GET is 405, tenant isolation with `tenant != maintenant`, filters, deterministic pagination, invalid query errors. |
| Retention/index | Correct collection indexes, correct retention timestamp, boundary tests, startup reconciliation, and no accidental data expiry. |
| Failure path | Structured metadata log, metric, retry/dead-letter/error response, and a test that proves the path is not silent. |

## 11. Definition of done for a change

A change is complete only when it has an approved requirement/ADR basis, a traceable commit/PR description, focused tests, relevant contract/document updates, and no unresolved security or tenancy question. If a decision is missing, the correct result is a documented blocker—not a plausible implementation.
