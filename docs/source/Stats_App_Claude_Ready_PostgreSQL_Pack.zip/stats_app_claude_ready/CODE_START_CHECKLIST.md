# Stats App — Code-Start Checklist

This is the required gate between good architecture documents and safe implementation. Each completed decision must have an approver, decision date, and link to the resulting ADR or approved specification.

## A. Stop/go decision register

| ID | Decision | Required decision | Owner | Status | Blocks |
|---|---|---|---|---|---|
| D-01 | Platform baseline | Java/Kotlin, JDK, Spring Boot, Gradle DSL, reference project, approved dependency baseline. | Platform engineering | PENDING APPROVAL | Repository build and all executable code. |
| D-02 | V1 stat types | Confirm all five types, including formal rules for `netstats.json` nested interfaces and optionality. | Product + Heimdal owner | PENDING APPROVAL | `netstats` validation and final V1 acceptance. |
| D-03 | Inbound contract | Path, content type, request size, timeouts, auth, retryability, replay/backfill and duplicate behavior. | Heimdal owner + security | PENDING APPROVAL | Input Module. |
| D-04 | Inbound authentication | mTLS or OAuth2 client-credentials/JWT; client identity; issuer/audience; rotation; 401/403 rules. | Security + platform | PENDING APPROVAL | Input Module. |
| D-05 | Tenant policy | Required record field, validated token claim, `tenant` versus `maintenant`, tenantless records, privileged access model. | Security + product | PENDING APPROVAL | Persistence and API. |
| D-06 | AMQP topology | Exchange type/name, queue naming, bindings, durable settings, retries/backoff, DLQ/redrive, topology owner. | Platform + engineering | PENDING APPROVAL | Input and Writer. |
| D-07 | Delivery/idempotency | At-least-once semantics, publisher confirms, ACK point, `uid` uniqueness scope, duplicate outcome. | Heimdal owner + engineering | PENDING APPROVAL | Input and Writer. |
| D-08 | PostgreSQL persistence | Table/column design, typed columns versus `jsonb`, unique `uid`, partitioning, `(tenant, gateway, ts.device)` indexes, retention job/partition strategy, migrations, backups. | Data/platform + engineering | PENDING APPROVAL | Writer. |
| D-09 | API contract | OpenAPI paths, roles/claims, filters, time format, response envelope, sorting, cursor/pagination, limits, error catalog. | API consumers + security | PENDING APPROVAL | API. |
| D-10 | Deployment/scaling | Three application artifacts, runtime platform, per-type writer scaling, environment configuration, readiness probes. | Platform engineering | PENDING APPROVAL | Packaging and release. |
| D-11 | Capacity and SLOs | Base design on 160,000 gateways reporting every 10 minutes: 23.04m records/type/day, 92.16m/day for four types, 115.2m/day for five types; also define burst rate, payload sizes, reads, latency, backlog, RTO/RPO, and replay target. | Product + operations | PENDING APPROVAL | PostgreSQL sizing and load testing. |
| D-12 | Data handling | Data classification, masking, log/DLQ retention, access controls, encryption, audit, backup/restore, deletion. | Security + compliance | PENDING APPROVAL | Production logging, DLQ, operations. |

> **Rule:** A developer may implement only the work that does not rely on an unanswered row. A row marked `PENDING APPROVAL` is not permission to assume the recommended option.

## B. Approved implementation sequence

### Phase 0 — Design lock

**Exit criteria:** D-01 through D-12 have owners and due dates; the architecture, SRS, and BRD amendments are reviewed; the OpenAPI/AMQP/schema documents exist as reviewable drafts.

The team may draft contracts, gather samples, create ADRs, and schedule the decision workshop. It may not declare production security, topology, or public endpoint behavior from guesses.

### Phase 1 — Foundation

**Entry criteria:** D-01 is approved.

Create the Gradle multi-project structure, shared envelope model, baseline configuration, Docker Compose development stack with PostgreSQL/RabbitMQ/Keycloak, CI, code-quality tools, PostgreSQL Testcontainers support, and standard error/logging abstractions. This phase creates no public API and does not claim to finalize credentials, AMQP retries, or data retention.

### Phase 2 — Ingestion and persistence for specified types

**Entry criteria:** D-02 through D-08 and D-10 are approved for the type being built.

Implement the Input Module and Stats Writer for all approved stat types, including `netstats` once its supplied sample has been converted into an approved formal schema. Include validation, no transformation of the already canonical message, publisher confirmation, durable per-type broker topology, PostgreSQL idempotency, partition/index/retention strategy, retry/DLQ, metrics, and integration tests.

### Phase 3 — API

**Entry criteria:** D-05, D-09, D-10, and D-12 are approved and the OpenAPI contract is signed off.

Implement Keycloak resource-server integration, token claim mapping, strict tenant-scoped repository queries, GET-only endpoints, deterministic pagination, response/error mapping, and contract tests. There is no tenant query parameter in the ordinary API unless a separately approved privileged access model exists.

### Phase 4 — Operational readiness and release

**Entry criteria:** D-11 and D-12 are approved; the operations runbook and dashboards exist.

Perform capacity/load testing, broker/DB failure tests, graceful-shutdown and redelivery tests, security tests, backup/restore verification, alert validation, DLQ redrive exercise, and consumer acceptance testing. Production release is blocked until observability and ownership are proven.

## C. Minimum acceptance evidence

| Capability | Evidence required |
|---|---|
| Input validation | Schema test suite with valid, invalid, unknown-type, wrong-type, and timestamp fixtures. |
| Tenant security | Integration test that proves a token for tenant A cannot obtain tenant B data when `tenant` differs from `maintenant`. |
| Reliable delivery | Test showing success only after broker confirmation, at-least-once redelivery, duplicate handling, retry limit, and DLQ behavior. |
| Retention | Index/deletion test at the expiry boundary, configuration reconciliation test, and verification of selected timestamp semantics. |
| API | Approved OpenAPI diff, automated contract tests, 401/403/405 tests, query/pagination/cursor tests, and non-leaky errors. |
| Operations | Metrics on processed/error/duration/queue depth per type, dashboard screenshot or configuration, alert tests, and runbook rehearsal. |

## D. Decision workshop agenda

The fastest path to code is a 90-minute workshop with the Heimdal owner, platform/security owner, API consumer representative, product owner, and lead engineer. Decide D-01 through D-09 in the first session and assign D-10 through D-12 with dates. Bring real non-production sample records and exact delivery/replay behavior from Heimdal.
