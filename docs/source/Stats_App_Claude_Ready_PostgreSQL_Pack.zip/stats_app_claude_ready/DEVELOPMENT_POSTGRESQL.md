# Stats App Local Development — PostgreSQL Baseline

## 1. Required local tools

Install VS Code, Java 21, Git, Docker Desktop or Docker Engine with Compose, and the extensions in `vscode/VS_CODE_SETUP.md`. Do not install Gradle globally; use the repository wrapper.

## 2. Local infrastructure

The local Compose stack must provide:

| Service | Development purpose | Typical port |
|---|---|---:|
| PostgreSQL | V1 database; one table per type. | 5432 |
| RabbitMQ | Topic exchange, per-type queues, retry/DLQ flow. | 5672 / 15672 |
| Keycloak | Local API authentication and dummy `readOnly` role. | 8080 |

The local stack must not include MongoDB. Local credentials are placeholders only and must not be reused in production.

## 3. Build and run

```bash
# Linux/macOS
./gradlew build
./gradlew test
./gradlew integrationTest

# Start infrastructure
docker compose -f docker/docker-compose.yml up -d

# Run one service per terminal
./gradlew :stats-input:bootRun
./gradlew :stats-writer:bootRun
./gradlew :stats-api:bootRun
```

On Windows, use `gradlew.bat` instead of `./gradlew`.

## 4. PostgreSQL verification

Use the PostgreSQL VS Code extension or `psql` to verify connectivity. The exact database name/user are environment configuration and must not be hard-coded.

```bash
psql "$POSTGRES_URL" -c 'select version();'
psql "$POSTGRES_URL" -c '\dt'
psql "$POSTGRES_URL" -c 'select count(*) from lorastats;'
```

After the Writer starts, verify that versioned migrations have created the approved tables, unique `uid` constraints, `(tenant, gateway, ts.device)` indexes, and retention/partition structures. Do not manually edit schema in a running environment; create a migration.

## 5. End-to-end smoke path

1. Start PostgreSQL, RabbitMQ, and Keycloak.
2. Start the Writer so it declares/validates the approved topology and migrations.
3. Start Input and API.
4. POST one valid fixture for each type, including the supplied `netstats` sample.
5. Verify the broker confirm response.
6. Verify each type queue drains and the corresponding PostgreSQL table receives one row.
7. Obtain a local token with the dummy `readOnly` role and the test tenant claim.
8. GET `/v1/stats/{type}` with gateway/time filters; verify ordering uses `ts.device` and tenant filtering is server-side.
9. Send an invalid record and verify 400, Problem Details, safe log behavior, and no queue message.
10. Stop PostgreSQL, send a valid record, verify non-2xx/queue behavior, retry/DLQ metrics, then restart PostgreSQL and verify recovery.

## 6. PostgreSQL testing requirements

Use a real PostgreSQL Testcontainer for repository, migration, index, transaction, duplicate, retention, and pagination tests. Use RabbitMQ Testcontainers for routing, durable queues, publisher confirms, retry/DLQ, and poison-message isolation. Use end-to-end Compose only for local manual verification.

The clarified load baseline is 160,000 gateways reporting every 10 minutes for every type:

```text
23,040,000 records/type/day
92,160,000 records/day for four types
115,200,000 records/day for five types
```

Load testing must include synchronized ten-minute bursts and database outage/recovery; average-rate tests alone are insufficient.
