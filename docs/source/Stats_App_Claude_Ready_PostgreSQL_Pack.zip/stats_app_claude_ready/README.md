# Stats App — Claude-Ready Implementation Pack

**Status:** Draft implementation baseline; requires decisions marked `PENDING APPROVAL` before the affected production code is written.

This pack does not overwrite the original SRS, BRD, ARB, or engineering notes. It is an editable, implementation-focused supplement that resolves their structural gaps, keeps unresolved business decisions visible, and gives Claude Code a consistent source of truth.

## Read this first

The original requirements establish the non-negotiable system boundaries: the Input Module validates and publishes; the Stats Writer is the only database writer; the Stats API is GET-only; stat types are isolated; and tenant isolation is enforced server-side. The current answered decision changes the persistence baseline to **PostgreSQL only**, with one table per stat type and three Docker images. The original source requirements remain authoritative until the corresponding amendments are approved. [1][SRS] [2][OriginalClaude]

> **Do not ask Claude to “finish the whole app.”** Work in small requirement-traceable slices. Claude must first read `CLAUDE.md`, the relevant ADR, the relevant contract, and the applicable acceptance criteria. It must propose a plan, wait for approval, make the smallest safe change, run the named tests, and report the requirement IDs satisfied.

## Pack contents

| File or directory | Purpose | Coding gate |
|---|---|---|
| `CLAUDE.md` | Project-specific rules for Claude Code and human engineers. | Always read first. |
| `CODE_START_CHECKLIST.md` | Decision gates and phased implementation plan. | Must pass the applicable phase gate. |
| `Stats_App_ARB_v1.2_PostgreSQL_Amendment.md` | Architecture decisions, target topology, operational concerns, and ARB approvals. | Required before infrastructure and service design. |
| `Stats_App_SRS_v1.2_PostgreSQL_Amendment.md` | Corrected PostgreSQL-only, five-type, testable requirements and formal clarifications. | Required before feature code. |
| `Stats_App_BRD_v1.2_PostgreSQL_Amendment.md` | V1 scope, consumer use cases, business acceptance, and stakeholder decisions. | Required before API scope is committed. |
| `adr/` | Architecture decision records. | Required where an ADR covers the feature. |
| `contracts/` | Heimdal HTTP, OpenAPI, and AMQP topology contracts. | Required before API or messaging code. |
| `schemas/` | Schema-catalogue convention and payload schemas when approved. | Required before validation code. |
| `POSTGRESQL_IMPLEMENTATION_BASELINE.md` | PostgreSQL-only tables, indexes, partitioning, retention, and volume guidance. | Required before persistence code. |
| `DEVELOPMENT_POSTGRESQL.md` | Local PostgreSQL/RabbitMQ/Keycloak setup, migrations, smoke test, and load baseline. | Required before local execution. |
| `ANSWER_RECONCILIATION.md` | New answer decisions, netstats interpretation, and volume correction. | Required before coding against the new baseline. |
| `vscode/VS_CODE_SETUP.md` | From-zero machine and VS Code setup, including PostgreSQL tooling. | Required before local development. |
| `.vscode/` | Recommended extensions, tasks, debugger configuration, and workspace settings. | Copy into the actual repository root. |
| `contracts/heimdal-input-contract-v1.md` | Draft Heimdal HTTP path, response, auth, and replay contract. | Required before Input implementation. |
| `CLAUDE_PROMPTS.md` | Safe, staged prompts for planning, implementation, review, and debugging. | Use instead of unbounded prompts. |

## Suggested repository layout

Copy this pack into the future repository root and retain the original source documents under `docs/source/`.

```text
stats-app/
├── CLAUDE.md
├── CODE_START_CHECKLIST.md
├── docs/
│   ├── source/                         # unchanged original files
│   ├── architecture/                   # ARB amendment and ADRs
│   ├── requirements/                   # SRS/BRD amendments
│   ├── contracts/                      # OpenAPI and AMQP topology
│   └── schemas/                        # JSON Schema catalogue and fixtures
├── stats-common/
├── stats-input/
├── stats-writer/
├── stats-api/
├── docker/
├── .vscode/
└── gradle/
```

## Claude Code working agreement

Use **Plan** permission mode for design and feature work. Review every change before accepting it. The Claude Code VS Code extension supports plan review, file references, and side-by-side diffs; it requires VS Code 1.94 or later and an eligible Anthropic account or Console account. [3][ClaudeVSCode]

For every implementation request, give Claude the relevant requirement and acceptance test. For example:

```text
Read @CLAUDE.md, @docs/requirements/Stats_App_SRS_v1.2_PostgreSQL_Amendment.md,
@docs/architecture/adr/ADR-002-AMQP-Topology.md, and @docs/contracts/amqp-topology-v1.md.

Do not write code yet. Produce a concise plan for STA-10, STA-12, STA-13, STA-20,
and STA-25. Identify every decision that remains PENDING APPROVAL, the tests we
need, and the files that would change. Wait for my approval before editing.
```

## References

[SRS]: ../upload/Datahub_Core_StatsApp_SRS_v1_0_EN.docx "Datahub Core Stats App SRS v1.0 — user-provided"
[OriginalClaude]: ../upload/CLAUDE.md "Original Stats App CLAUDE.md — user-provided"
[ClaudeVSCode]: https://code.claude.com/docs/en/vs-code "Anthropic — Use Claude Code in VS Code"

[1][SRS] [2][OriginalClaude] [3][ClaudeVSCode]
