# ADR-001 — JVM and Spring Platform Baseline

**Status:** `PENDING APPROVAL`  
**Decision owner:** Platform engineering  
**Date:** 13 August 2026

## Context

The requirements specify a multi-module Gradle project and `application.properties`, but do not select Java or Kotlin, a JDK, Spring Boot version, Gradle DSL, or reference project. These choices determine code shape, dependency management, test support, deployment, observability, secrets, and maintainability.

## Decision required

| Decision item | Approved value |
|---|---|
| Language | **Java 21** |
| JDK | **Java 21** |
| Spring Boot | **Greater than 3.5.x; exact reproducible version PENDING APPROVAL** |
| Gradle DSL | PENDING APPROVAL: Groovy or Kotlin DSL |
| Build wrapper | Gradle Wrapper only; no globally required Gradle version. |
| Reference repository | PENDING APPROVAL: internal service to copy CI, deployment, observability, and security conventions from. |
| Test stack | JUnit, Spring Boot Test, Testcontainers for PostgreSQL/RabbitMQ, and contract tests—subject to platform policy. |

## Provisional development rule

Java 21 is now selected. Before committing the production build, record the exact Spring Boot version, Gradle version catalog, Gradle DSL, and internal reference project. If a local proof of concept uses a different Spring Boot version, label it non-production and isolate it so the approved baseline can replace it. Do not let a proof of concept silently become the production standard.

## Consequences

Java 21 unblocks source roots and the developer JDK. The exact Spring Boot version still blocks reproducible Gradle dependency configuration. When fixed, this ADR unblocks the version catalog, dependency management, formatting/linting tools, CI baseline, Docker base images, and PostgreSQL Testcontainers setup. It does not approve security, broker topology, data retention, or API behavior.
