# ADR-002 — Per-Type RabbitMQ Topology and Ownership

**Status:** `PENDING APPROVAL`  
**Decision owner:** Platform engineering / Architecture Review Board  
**Requirements:** STA-04, STA-10 through STA-14, STA-20, STA-25 through STA-27

## Context

The SRS requires a dedicated queue and consumer per stat type. The implementation brief names one `app_statsstore` queue. A shared queue violates type isolation, prevents independent consumer scaling, and permits head-of-line blocking when a poison message of one type holds up other types.

## Proposed decision

1. `app_stats_input` is the ingress exchange.
2. The routing key equals the exact approved stat type.
3. Every stat type has a dedicated durable main queue named `app_statsstore.<type>`.
4. Every type has a dedicated retry/DLQ path as specified in `contracts/amqp-topology-v1.md`.
5. Main queues, retry queues, dead-letter queues, exchange, and bindings are durable. Ingress publishes persistent messages.
6. Every broker-connected module declares identical topology, as answered. Confirm whether `stats-api` is intended to connect to RabbitMQ; if it is not broker-connected, it does not declare broker resources. Declaration arguments must be identical and integration-tested to prevent RabbitMQ resource-lock errors.
7. The Input service confirms publish success before returning an acceptance response.

## Proposed topology

```text
app_stats_input exchange [TopicExchange]
  | lorastats -> app_statsstore.lorastats -> writer:lorastats -> lorastats collection
  | ltestats  -> app_statsstore.ltestats  -> writer:ltestats  -> ltestats collection
  | sysstats  -> app_statsstore.sysstats  -> writer:sysstats  -> sysstats collection
  | omsstats  -> app_statsstore.omsstats  -> writer:omsstats  -> omsstats collection
  | netstats  -> app_statsstore.netstats  -> writer:netstats  -> netstats table [draft schema rules pending]
```

## Alternatives rejected

| Alternative | Rejection reason |
|---|---|
| One shared `app_statsstore` queue | Conflicts with STA-10/20, causes shared failure domain and shared scaling bottleneck. |
| Input service writes PostgreSQL directly | Violates buffer/decoupling and single-writer architecture. |
| Input service owns all topology permanently | Couples ingress deployability to persistence infrastructure ownership; use only if explicitly approved by platform. |

## Consequences and tests

Each stat type needs a dedicated binding, consumer configuration, metrics, DLQ alarm, and isolation test. A poison message in one type must not slow delivery for another type. Every topology argument must be identical across local, test, and production environment definitions.
