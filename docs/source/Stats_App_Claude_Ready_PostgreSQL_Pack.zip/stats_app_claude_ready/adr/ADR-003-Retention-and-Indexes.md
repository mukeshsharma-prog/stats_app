# ADR-003 — PostgreSQL Retention, Partitioning, and Index Management

**Status:** `PENDING APPROVAL`  
**Decision owner:** Data platform / Architecture Review Board  
**Requirements:** STA-21, STA-23, STA-24, STA-26, STA-34 through STA-36

## Context

PostgreSQL is now the only V1 database. The business answer selects `ts.device` as the retention basis and identifies tenant, gateway, and `ts.device` as the dominant query pattern. At 160,000 gateways reporting every 10 minutes, the average workload is 23.04 million records per type per day and can reach 115.2 million records/day for five types before synchronized reporting bursts are considered.

A simple row-by-row deletion job may create table/index bloat, long-running transactions, lock contention, and unacceptable writer impact. Retention must therefore be designed with PostgreSQL partitioning and operational behavior in mind.

## Proposed decision

1. Every stat type has its own PostgreSQL table.
2. Retention uses `ts.device`, as answered by the business owner.
3. The Writer/retention component owns retention configuration and emits deletion/partition lag metrics.
4. Prefer time partitioning aligned with the `ts.device` retention/query model. Partition granularity—daily, hourly, or another interval—requires capacity testing.
5. If partitioning is not approved for the first increment, use bounded, indexed, resumable deletion batches and explicitly accept the bloat/maintenance trade-off.
6. Retention configuration remains external:

```properties
stats.retention.default-days=90
stats.retention.lorastats-days=
stats.retention.ltestats-days=
stats.retention.sysstats-days=
stats.retention.omsstats-days=
stats.retention.netstats-days=
stats.retention.delete-batch-size=PENDING
stats.retention.schedule=PENDING
```

7. Retention behavior for late-arriving records is documented: a record with an old `ts.device` can be near expiry when it is received. This is an accepted consequence of the business-selected timestamp and must be covered by boundary tests.

## Required table/index direction

Every table contains `uid` as a normal text column with a unique constraint, common envelope columns, `ts_device`, `ts_processor`, a retention field or partitioning basis, and the approved type-specific data representation.

The dominant index proposal is:

```sql
CREATE UNIQUE INDEX uq_<type>_uid ON <type> (uid);

CREATE INDEX idx_<type>_tenant_gateway_device_uid
    ON <type> (tenant, gateway, ts_device DESC, uid DESC);
```

The final design must decide whether type-specific data is typed SQL columns or `jsonb`. Dominant filters must not depend on unindexed JSON path scans.

## Decisions required before production

| Decision | Why it matters | Status |
|---|---|---|
| Exact PostgreSQL version/managed service | Determines features, driver, HA, and operational controls. | PENDING |
| Partition key and granularity | Determines retention cost, query pruning, locks, and migration complexity. | PENDING |
| Typed columns versus `jsonb` | Determines write cost, schema evolution, and query/index efficiency. | PENDING |
| Retention job/partition owner | Prevents duplicate deletion processes and conflicting migrations. | PENDING |
| Batch size, schedule, and transaction limit | Controls lock duration and Writer impact. | PENDING |
| Backup/PITR/restore targets | Required for recovery and acceptance. | PENDING |
| Migration tool | Use approved Flyway, Liquibase, or platform standard. | PENDING |

## Consequences and tests

Retention tests must prove records just inside the boundary remain and records outside the boundary are removed according to the actual PostgreSQL mechanism. Load tests must measure write throughput, query latency, partition pruning, deletion/partition-drop lag, vacuum behavior, table/index growth, and recovery after database outage.
