# ADR-004 — OMS Timestamp Normalization

**Status:** `ACCEPTED`  
**Decision owner:** Heimdal Core owner / Engineering lead  
**Requirements:** STA-02, STA-03, STA-04, STA-21, STA-23

## Decision

Heimdal already sends the canonical `ts.processor` field for `omsstats`. Stats App performs **no timestamp normalization** and must publish the message identically to the received canonical record.

The Writer, PostgreSQL tables, retention process, and API must use the common `ts.processor`/`ts.device` envelope. The business-selected query and retention timestamp is `ts.device`; `ts.processor` remains the processing timestamp.

## Consequences

There is no `ts.converter` handling in the Input Module or downstream services. A legacy `ts.converter` record is invalid unless a future approved compatibility ADR reopens this decision. Contract tests must prove that an OMS record with `ts.processor` is accepted unchanged and that no transformation occurs between HTTP input and AMQP publication.
