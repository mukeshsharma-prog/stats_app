# ADR-005 — Delivery Semantics and PostgreSQL Idempotency

**Status:** `ACCEPTED WITH IMPLEMENTATION DEFAULTS`  
**Decision owner:** Heimdal Core owner / Engineering lead  
**Requirements:** STA-04, STA-12, STA-13, STA-20, STA-25

## Confirmed facts

Heimdal states that `uid` is unique and that it does not intentionally deliver duplicates. Heimdal owns dead-letter handling when it receives a non-2xx response from the Input Module. The Input Module must return success only after RabbitMQ publisher confirmation and must return non-2xx when RabbitMQ is unavailable.

## Decision

The Stats App uses **at-least-once processing with PostgreSQL idempotency defense**.

1. Input publishes persistent messages with publisher confirms.
2. Input returns 2xx only after broker confirmation.
3. Input returns a non-2xx response—503 by engineering default—when RabbitMQ is unavailable or confirmation times out.
4. Writer acknowledges only after a successful PostgreSQL transaction.
5. `uid` is stored as its own PostgreSQL column with a unique constraint/index, not as a database-specific document identifier.
6. If redelivery occurs despite Heimdal’s no-duplicate behavior, a unique-constraint conflict is handled as an idempotent duplicate only after verifying the existing record matches the approved identity policy.
7. Transient PostgreSQL failures follow bounded retry and per-type DLQ policy. Permanent failures or exhausted retries are visible in the type DLQ, logs, metrics, and alerts.

## Remaining implementation choices

| Choice | Default | Reason |
|---|---|---|
| Consumer ACK | After successful PostgreSQL transaction | Prevents silent loss before persistence and satisfies STA-25. |
| Writer batching | Individual writes initially; benchmark before batching | Simplifies per-record retry/DLQ semantics. |
| Duplicate handling | Unique constraint + safe duplicate outcome | Defense in depth even though upstream says duplicates do not occur. |
| Input broker failure | HTTP 503/non-2xx; no local Input buffer | Keeps Input stateless and activates Heimdal retry/dead-letter behavior. |

## Required tests

Test publisher-confirm timing, broker failure/non-2xx, manual ACK after transaction, PostgreSQL rollback, redelivery after a crash window, duplicate `uid`, retry limit, DLQ routing, and recovery after the database becomes available.
