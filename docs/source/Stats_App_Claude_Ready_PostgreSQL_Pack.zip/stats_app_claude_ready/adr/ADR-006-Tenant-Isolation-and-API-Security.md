# ADR-006 — Tenant Isolation and API Security

**Status:** `PENDING APPROVAL`  
**Decision owner:** Security owner / API owner / Product owner  
**Requirements:** STA-05, STA-31, STA-32, STA-34, STA-35

## Context

The SRS requires Keycloak protection and server-side tenant separation. The business answer confirms every record has a tenant. Input records have both `tenant` and `maintenant`, and examples often set them equal; this makes a wrong implementation appear correct in simple tests while leaking data in real deployments. A local dummy `readOnly` role may be used, but production realm/client/issuer/audience/tenant-claim values remain deployment configuration.

## Proposed decision

1. The data isolation field is `tenant`, not `maintenant`.
2. Every normal API request derives its effective tenant only from a **validated Keycloak token claim**.
3. Repository/database queries include the tenant predicate; controllers do not accept a normal `tenant` override parameter.
4. The response for a cross-tenant identifier/query is an empty result or ordinary not-found behavior defined in the OpenAPI; it must not confirm another tenant’s data exists.
5. Every accepted record must contain a valid tenant. The business answer confirms tenant presence; a missing tenant is a validation failure and is not silently stored as a placeholder.
6. The API is GET-only. An authenticated caller without the approved reader authority receives 403; unauthenticated callers receive 401.
7. Privileged cross-tenant/support access is **not included** until separately specified with role, audit, rationale, filtering, and security approval.

## Required platform inputs

| Input | Approved value |
|---|---|
| Keycloak issuer/realm URL | PENDING APPROVAL |
| Resource/client identifier and audience | PENDING APPROVAL |
| Role/scope name for normal Stats reader | Local dummy: `readOnly`; production value PENDING APPROVAL |
| Tenant claim name and type | PENDING APPROVAL; must map to the stored `tenant` field |
| Claim validation and normalization rules | PENDING APPROVAL |
| Token clock-skew and refresh behavior | PENDING APPROVAL |
| Dedicated Stats client versus existing Core client | PENDING APPROVAL |

## Mandatory security tests

* Valid token with reader authority and correct tenant reads only that tenant's records.
* Valid token without reader authority receives 403.
* Missing/invalid/expired token receives 401.
* A request cannot override tenant using query parameter, header, path, or body.
* A fixture with `tenant != maintenant` proves only `tenant` controls isolation.
* Every query path, count, cursor, and future aggregate includes the tenant predicate.
* POST, PUT, PATCH, and DELETE produce 405 and no database side effect.
