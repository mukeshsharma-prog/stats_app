# Stats App AMQP Contract and Topology — V1 Draft

**Status:** `PENDING PLATFORM APPROVAL`  
**Applies to:** Stats Input publisher, RabbitMQ infrastructure, Stats Writer consumers.  
**Requirements:** STA-04, STA-10 through STA-14, STA-20, STA-25 through STA-27.

## 1. Canonical message

The Input Module validates the common envelope and selected type schema before publication. The published message is the canonical, normalized record. For OMS, canonicalization follows ADR-004. The message MUST contain a `type` whose literal matches the AMQP routing key, selected queue, schema, consumer, and persistence collection.

| Property | Value |
|---|---|
| Content type | `application/json` |
| Delivery mode | Persistent |
| Correlation ID | `uid` unless platform tracing supplies an approved additional ID |
| Message body | Canonical validated JSON record |
| Routing key | Exact `type` literal |
| Publisher guarantee | Confirm required before successful HTTP acceptance |

## 2. Exchange and queues

| Resource | Proposed name | Type / purpose | Durable | Owner |
|---|---|---|---:|---|
| Ingress exchange | `app_stats_input` | `TopicExchange` | Yes | Every broker-connected module declares identical topology; confirm whether `stats-api` is broker-connected. |
| Main queue | `app_statsstore.<type>` | Main work queue per type | Yes | Every broker-connected module must declare the identical durable definition; topology conflict testing required. |
| Retry queue | `app_statsretry.<type>` | Delayed/redelivery holding queue per type | Yes | Same sole owner |
| Dead-letter queue | `app_statsdlq.<type>` | Final failed messages per type | Yes | Same sole owner |
| Dead-letter exchange | `app_stats_dlx` | Route failures/retry paths | Yes | Same sole owner |

`<type>` is one of the five V1 types: `lorastats`, `ltestats`, `sysstats`, `omsstats`, and `netstats`. `netstats` uses the supplied sample as a draft fixture; strict nested-field rules remain pending confirmation.

## 3. Main flow

```text
HTTP Input
  -> validate schema and authenticated source
  -> publish persistent JSON to app_stats_input using routing key <type>
  -> receive publisher confirm
  -> return 2xx accepted response

app_stats_input
  -> app_statsstore.<type>
  -> dedicated <type> consumer
  -> idempotent PostgreSQL persistence
  -> manual ACK after success
```

## 4. Failure and retry flow

| Failure class | Example | Proposed handling | Approval needed |
|---|---|---|---|
| Input validation | Missing field, wrong type, unknown stat type | Return 400; safe log; no publish. | Error contract approval |
| Input auth | Invalid Heimdal identity | 401/403; no publish. | Security approval |
| Broker publish | Broker unavailable or confirm timeout | Return 503; safe metric/log; rely on upstream retry/replay. | Inbound contract approval |
| Transient persistence | PostgreSQL timeout/temporary unavailable | Reject/requeue or route to retry queue with approved bounded delay/backoff. | Retry policy approval |
| Duplicate | Redelivery after write/ACK gap | Idempotent success; ACK; record duplicate metric. | `uid`/idempotency approval |
| Permanent persistence | Schema mapping failure, violated invariant | Route to type DLQ; safe error log and metric. | Error taxonomy approval |
| Retry exhausted | Repeated transient failure | Move to type DLQ; alert. | Retry count/delay approval |

The retry policy must be explicit. The following values are placeholders and must not be copied into production configuration without approval:

```properties
stats.amqp.max-retries=PENDING
stats.amqp.retry-initial-delay-ms=PENDING
stats.amqp.retry-multiplier=PENDING
stats.amqp.retry-max-delay-ms=PENDING
stats.amqp.dlq-retention-ms=PENDING
```

## 5. Required consumer configuration

| Setting | Requirement |
|---|---|
| Consumer binding | Exactly one type per listener/binding. |
| Acknowledgement | Manual, after successful idempotent write. |
| Concurrency | Per type; external configuration. |
| Prefetch | Per type; external configuration and capacity-tested. |
| Error classification | Explicit mapping from exception category to retry, DLQ, or alert. |
| Graceful shutdown | Stop intake, complete in-flight work within grace period, return unacknowledged work safely to queue. |
| Metrics | Per type: receive, success, duplicate, retry, DLQ, processing duration, consumer availability, queue depth. |

## 6. Redrive/runbook contract

Only an authorized operations role may inspect or replay DLQ messages. Redrive must be explicit, traceable, rate-limited, and scoped per type. Before redrive, operators must identify and resolve the root cause; blind automatic replay is not permitted. The final operations runbook must define access, payload masking, audit evidence, maximum replay rate, and success verification.

## 7. Contract tests

The automated integration suite must prove all of the following for each type:

1. A validated message uses the correct routing key and reaches only its type queue.
2. Main/retry/DLQ queues are durable and accepted messages survive broker restart.
3. A database outage follows the approved retry path; it does not discard or pre-ACK a message.
4. A permanent failure reaches only the appropriate type DLQ.
5. A poison message in one type does not prevent a different type from persisting.
6. A redelivery after persistence does not produce duplicate data.
7. All metrics and logs identify the stat type and `uid` without sensitive payload leakage.
