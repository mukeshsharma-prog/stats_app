# Heimdal Core -> Stats Input HTTP Contract v1 Draft

**Status:** `PENDING HEIMDAL AND SECURITY APPROVAL`  
**Upstream owner:** ZC / Heimdal Core  
**Input service:** `stats-input`

## 1. Endpoint

| Item | Draft value |
|---|---|
| Method | `POST` |
| Path | `/stats` (confirm against the deployed Datahub API convention) |
| Content type | `application/json` |
| Body | One canonical statistics record per request |
| Success meaning | The record passed validation and RabbitMQ publisher confirmation completed. |
| Correlation | `uid` from the record; platform trace header may be added if approved. |

The Input Module validates the received message and publishes it byte-identically/canonically as answered. Stats App does not transform `omsstats` timestamps because Heimdal already sends `ts.processor`.

## 2. Response matrix

| Condition | Draft status | Heimdal behavior |
|---|---:|---|
| Valid record and publisher confirm | 200 or 202, exact code pending | Treat as accepted; do not redeliver. |
| Invalid JSON/schema/unknown type | 400 | Do not retry unchanged record; fix sender/schema. |
| Missing/invalid inbound credentials | 401 | Configuration/credential issue; do not retry blindly. |
| Authenticated but forbidden | 403 | Configuration/identity issue. |
| RabbitMQ unavailable/confirm timeout | 503 | Heimdal dead-letter/retry handling applies because response is non-2xx. |
| Request too large | 413 | Do not retry without correcting payload. |
| Rate limited/temporary overload | 429 or 503, exact policy pending | Retry using approved backoff. |
| Unexpected Input failure | 5xx | Heimdal dead-letter/retry handling applies. |

The exact successful status, retryable status list, retry schedule, and maximum retry/retention behavior must be approved with ZC.

## 3. Authentication

The protocol is **PENDING SECURITY APPROVAL**. Select the existing Datahub service-to-service convention, with one of:

* OAuth2 client credentials/JWT, including issuer, audience, client identity, scopes, and rotation; or
* mTLS, including certificate identity, trust chain, rotation, and revocation.

Credentials, tokens, private keys, and secrets are never stored in the repository or logged.

## 4. Validation contract

The message must satisfy the common envelope and the schema selected by `type`. The current V1 types are `lorastats`, `ltestats`, `sysstats`, `omsstats`, and `netstats`. The `netstats` sample is supplied; mandatory nested-interface rules remain pending.

Invalid responses use the approved RFC 9457-compatible Problem Details shape. The response may identify field names, reason codes, stat type, and `uid`, but must not echo sensitive offending values or access credentials. The business answer permits payload logging in the Java logger/Docker logs; production data-classification and access policy still governs what is retained and who can see it.

## 5. Delivery/replay behavior

The Input Module is stateless and does not buffer locally. If RabbitMQ cannot accept/confirm the message, Input returns non-2xx and Heimdal owns dead-letter/retry handling. The ZC owner must confirm whether Heimdal replays the same `uid` after recovery and what burst size can occur during replay. PostgreSQL retains a unique `uid` defense even though Heimdal states duplicates are not intentionally delivered.

## 6. Contract tests

The integration suite must verify valid and invalid samples for each type, response status and body, no publish on 400/auth failure, publisher-confirm timing, broker outage returning non-2xx, same `uid` correlation, and safe handling of a replay/redelivery.
