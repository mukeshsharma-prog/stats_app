# Stats App API — OpenAPI 3.1 Design Draft

**Status:** `PENDING CONSUMER AND SECURITY APPROVAL`  
**Base path:** `/v1`  
**Security:** Keycloak OAuth2/OIDC bearer JWT; exact issuer/audience/role/tenant claim are pending ADR-006.

This document is the human-readable design input for the machine-readable `openapi.yaml` that must be committed before API controllers are implemented.

## 1. API principles

The API is tenant-scoped and GET-only. A normal caller’s tenant is derived from the validated access token; there is **no caller-controlled `tenant` query parameter**. Every operation has a mandatory deterministic sort and stable cursor pagination. The V1 type set is `lorastats`, `ltestats`, `sysstats`, `omsstats`, and `netstats`. The `netstats` sample is available; its nested optionality and strict validation rules remain explicitly documented as pending.

## 2. Endpoints

| Method | Path | Purpose | Required role |
|---|---|---|---|
| GET | `/v1/stats/{type}` | Retrieve a single approved stat type for the authenticated tenant. | `PENDING: stats-reader` |
| GET | `/v1/stats/{type}/{uid}` | Retrieve one record of a type for the authenticated tenant. | `PENDING: stats-reader` |
| GET | `/v1/openapi` | Optional rendered/schema discovery endpoint if platform convention supports it. | `PENDING` |
| GET | `/actuator/health/liveness` | Service liveness; platform/internal exposure only. | Platform policy |
| GET | `/actuator/health/readiness` | Dependency readiness; platform/internal exposure only. | Platform policy |

The `{type}` path parameter is an enumeration: `lorastats`, `ltestats`, `sysstats`, `omsstats`, `netstats`. An unsupported type returns 400 `unknown_stat_type` rather than falling through to a table name. `netstats` response data follows the approved draft schema and its final nested-field rules.

## 3. List operation

### `GET /v1/stats/{type}`

| Parameter | Location | Type | Required | Meaning |
|---|---|---:|---:|---|
| `type` | path | enum | Yes | Stat type. |
| `from` | query | RFC 3339 UTC date-time | No | Inclusive start of the approved query timestamp. |
| `to` | query | RFC 3339 UTC date-time | No | Inclusive end of the approved query timestamp. |
| `gateway` | query | string | No | Exact canonical gateway filter. |
| `cursor` | query | opaque string | No | Keyset page continuation token. |
| `pageSize` | query | integer | No | Default 100; hard maximum 1000, pending approval. |

The `tenant` is supplied by the token, not by this endpoint. The approved query timestamp is `ts.device`. The default ordering is newest first by `ts.device, uid`, which is deterministic and supports keyset pagination. `from` and `to` apply to `ts.device` and their boundary inclusivity must be frozen in the approved OpenAPI.

| Condition | HTTP status | Problem code / behavior |
|---|---:|---|
| Valid query / results exist | 200 | `StatsPage` response. |
| Valid query / no visible data | 200 | Empty `items`; no cross-tenant disclosure. |
| Unknown type | 400 | `unknown_stat_type`. |
| Invalid timestamp / malformed cursor / invalid page size | 400 | `invalid_parameter`. |
| `from` is after `to` | 400 | `invalid_time_range`. |
| Range exceeds approved maximum | 400 or 422 | `query_window_exceeded`; exact status pending approval. |
| No/malformed/expired token | 401 | `unauthorized`. |
| Authenticated but lacks role | 403 | `forbidden`. |
| Unsupported HTTP method | 405 | `method_not_allowed`. |

## 4. Single-record operation

### `GET /v1/stats/{type}/{uid}`

The repository query must use both the token-derived `tenant` and the `uid`. A record belonging to another tenant must not be returned. The exact choice between a `404` and an ordinary 200-empty semantics for a cross-tenant identifier is pending approval; it must not produce a distinct authorization error that reveals existence.

## 5. Success schemas

### `StatsPage`

```json
{
  "items": [
    {
      "uid": "2deb420f-56c8-452e-bdfd-53c9d455a9f9",
      "tenant": "<caller-visible tenant>",
      "maintenant": "<managing tenant>",
      "gateway": "04B648102511",
      "type": "lorastats",
      "ts": {
        "processor": "2026-08-13T10:15:30Z",
        "device": "2026-08-13T10:15:20Z"
      },
      "data": {}
    }
  ],
  "nextCursor": "<opaque cursor or null>",
  "pageSize": 100
}
```

The API returns timestamps as RFC 3339 UTC strings unless the approved Datahub convention requires Unix seconds. The inbound payload contains Unix seconds; serialization belongs to the API contract and must be documented/tested. The query and retention basis is `ts.device`. Whether `tenant` is returned to a tenant-scoped caller is an API privacy decision pending consumer/security review.

### `ProblemDetails`

```json
{
  "type": "https://<host>/errors/invalid-parameter",
  "title": "Invalid request parameter",
  "status": 400,
  "detail": "The 'from' timestamp must be earlier than or equal to 'to'.",
  "instance": "/v1/stats/lorastats",
  "errors": [
    { "field": "from", "code": "after_to", "message": "Must not be later than 'to'." }
  ]
}
```

Problem responses must never contain access tokens, full stored records, IMSI, or identifiers that reveal another tenant’s data.

## 6. Contract requirements before implementation

1. Convert this document into `openapi.yaml` using OpenAPI 3.1.
2. Define security scheme, issuer/audience/roles, and tenant claim after ADR-006 approval; local development may use the dummy `readOnly` role.
3. Define type-specific `data` schemas through `$ref` to the approved JSON Schema catalogue.
4. Freeze parameter names, timestamp formats, error codes, ordering, cursor encoding, and compatibility policy with consumer review.
5. Generate controller/client contract tests from the approved contract.
