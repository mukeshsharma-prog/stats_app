# Stats App Schema Catalogue and Fixture Standard

**Status:** `PENDING INTEGRATION APPROVAL`  
**Purpose:** Provide machine-testable message contracts for Input validation, contract tests, Writer mapping, and API response references.

## 1. Required catalogue layout

```text
docs/schemas/
├── envelope-v1.schema.json
├── lorastats-v1.schema.json
├── ltestats-v1.schema.json
├── sysstats-v1.schema.json
├── omsstats-v1.schema.json
├── netstats-v1.schema.json              # draft from supplied netstats.json; strict rules pending
└── fixtures/
    ├── valid/
    ├── invalid/
    └── edge-cases/
```

A schema document is an executable contract, not sample documentation. The Input Module must select the schema by `type`, validate the envelope and payload, and return the approved error response without publishing invalid records.

## 2. Common envelope rules

| Field | Rule |
|---|---|
| `uid` | Required non-empty string. UUID format may be enforced only if Heimdal guarantees it for all records. |
| `tenant` | Required non-empty string; canonical format/allowed character set pending tenant-policy approval. |
| `maintenant` | Required non-empty string; deliberately test a value different from `tenant`. |
| `gateway` | Required 12 hexadecimal characters. Canonical upper/lower case must be selected and normalized/validated consistently. |
| `type` | Required literal enumeration; must match schema, routing key, queue, consumer, and collection. |
| `ts.processor` | Required integer Unix epoch seconds. |
| `ts.device` | Required integer Unix epoch seconds. |
| `data` | Required object, validated by selected schema. |

The accepted policy for unexpected fields is `PENDING APPROVAL`. The suggested default is to allow additive unknown payload fields and preserve them, but to reject unknown critical envelope fields only if the upstream-contract strategy requires strictness. This must not be silently decided in annotations or deserialiser settings.

## 3. Type schemas required from SRS v1.0

| Type | Required `data` fields |
|---|---|
| `sysstats` | `memfree` integer, `uptime` number, `idletime` number, `load1` number, `load5` number, `load15` number, `runable` string. |
| `lorastats` | `rx_nr_pkts`, `rx_crc_missing`, `rx_crc_bad`, `tx_success`, `tx_failed`, `tx_peek`, `tx_peek_index_zero`, `tx_override`, `tx_busy`, `tx_dequeue_error`, `tx_type_beacon`, `chip_comm_error`, `util_fopen_failed`—all integers. |
| `ltestats` | `rssi` integer, `rsrp` integer, `rsrq` integer, `access_technology` string, `operator` string, `plmn` integer, `imsi` string, `lac` string, `cid` string. |
| `omsstats` | `rx_nr_pkts` integer, `rx_valid_nr_pkts` integer, `rx_crc_bad` integer, `device_count` integer, `timespan` integer. OMS timestamp handling follows ADR-004. |
| `netstats` | Draft sample exists. `data.eth0`, `data.wwan`, and `data.timespan` are present in the sample; nested optionality, additional interfaces, IP formats, and counter representation require approval before strict rejection. |

## 4. Netstats-specific constraints requiring approval

The supplied sample contains `eth0` and `wwan` interface objects, string network counters, DNS string arrays, and an integer `timespan`. It does not establish mandatory/optional status, whether additional interfaces are valid, or formal network/counter validation. Keep the draft schema permissive enough for contract discussion and do not silently turn absent sample fields into required production fields.

## 5. Constraints still requiring approval

The SRS specifies field types and mandatory fields but usually not semantic ranges or maximum string lengths. Add a requirement or documented policy for each question below before enforcing it as a rejection condition.

| Topic | Decision required |
|---|---|
| Timestamp plausibility | Allowed historic/future skew, zero/negative values, maximum range. |
| Counter values | Whether negative values are invalid and whether counter reset/overflow is possible. |
| Gateway casing | Canonical casing and whether mixed case is normalized or rejected. |
| IMSI protection | Validation format, redaction/masking in fixtures/logs/errors, storage encryption requirement. |
| `runable` field | Exact regular expression and whether spelling is intentionally legacy. |
| String lengths | Maximum size for tenant, operator, cell IDs, etc. |
| Additional fields | Strict rejection, preservation, or schema-version-based acceptance. |
| Type/schema version | Header/property/field convention and compatibility rollout. |

## 6. Minimum fixture set per type

| Fixture | Required purpose |
|---|---|
| `valid-basic` | Demonstrates every mandatory field in the canonical shape. |
| `valid-tenant-different-maintenant` | Proves the two fields are independently preserved and tests API isolation correctly. |
| `invalid-missing-<field>` | One fixture per mandatory envelope and payload field. |
| `invalid-wrong-type-<field>` | Representative failures for numerical/string/object fields. |
| `invalid-unknown-type` | Proves 400 and no publish. |
| `invalid-timestamp-unit` | Proves Unix seconds are recognized; milliseconds are rejected/handled per approved policy. |
| `edge-late-device-timestamp` | Valid late record used to test retention timestamp selection. |
| `duplicate-uid` | Used after ADR-005 decision to prove idempotency. |
| `oms-legacy-timestamp` | Required only while ADR-004 permits it. |

Fixtures must contain fictional or non-sensitive values. Never put production IMSI, tenant, token, device-secret, or gateway data into the repository.

## 7. Schema change procedure

1. Propose a versioned JSON Schema change with examples and compatibility assessment.
2. Obtain Heimdal and consumer approval when inbound/API behavior changes.
3. Add positive, negative, compatibility, and migration fixtures.
4. Update the schema registry, Input validation, OpenAPI references, and contract tests in one traceable change.
5. Add an ADR if the change affects message routing, storage, retention, API compatibility, or security.
